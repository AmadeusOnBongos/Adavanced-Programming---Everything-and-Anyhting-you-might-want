

import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default class App extends React.Component {
  render() {
    return (
      <View style={styles.container}>
          <View style={styles.row}>
              <View style={styles.col2}>
                  <Text style={styles.paragraphRed}>Red</Text>
              </View>
              <View style={styles.col1}>
                  <Text style={styles.paragraphGreen}>Green</Text>
              </View>
          </View>
          <View style={styles.row}>
              <View style={styles.col3}>
                  <Text style={styles.paragraphBlue}>Blue</Text>
              </View>
              <View style={styles.col2}>
                  <Text style={styles.paragraphBlack}>Black</Text>
              </View>
              <View style={styles.col1}>
                  <Text style={styles.paragraphCyan}>Cyan</Text>
              </View>
          </View>
          <View style={styles.row}>
          <View style={styles.col1}>
                  <Text style={styles.paragraphYellow}>Yellow</Text>
              </View>
          </View>


        <Text style={styles.paragraph}>
          Welcome Haris Owais!
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
    flexDirection: 'column'
  },
  row: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
    flexDirection: 'row'
  },
  col1: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
    //flexDirection: 'row',
  },
  col2: {
    flex: 2,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
    //flexDirection: 'row',
  },
  col3: {
    flex: 3,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
    //flexDirection: 'row',
  },


  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraphBlack: {
    color: 'white',
    backgroundColor: 'black',
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraphBlue: {
    color: 'white',
    backgroundColor: 'blue',
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraphRed: {
    color: 'white',
    backgroundColor: 'red',
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    //flexDirection: 'row'
  },
  paragraphGreen: {
    color: 'white',
    backgroundColor: 'green',
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraphCyan: {
    color: 'white',
    backgroundColor: 'cyan',
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  paragraphYellow: {
    color: 'white',
    backgroundColor: 'yellow',
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});